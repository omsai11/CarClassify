#include<stdio.h>
#include<stdlib.h>

void main()
{
    int n;
    scanf("%d",&n);

    printf("Enter the array\n");
    int a[n];
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }

    //Insertion sort main code
    for(int i=1;i<n;i++)
    {
        int temp=a[i];
        int j=i-1;
        while(a[j]>temp && j>=0)
        {
            a[j+1]=a[j];
            j--;
        }
        a[j+1]=temp;
    }
    for(int i=0;i<n;i++)
    {
        printf("%d-->",a[i]);
    }
}