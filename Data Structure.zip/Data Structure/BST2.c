//Implementing binary search tree 2.0
#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node*left;
    struct node*right;
}*root,*node;

//creating function 
void create()
{   
    int val;
    printf("Enter the data:\n");
    scanf("%d",&val);

    struct node* p=(struct node*)malloc(sizeof(struct node));
    p->data=val;
    p->left=p->right=NULL;

    node=root;
    while(node!=NULL)
    {
        if(p->data<node->data)
        {
            if(node->left==NULL)
            {
                node->left=p;
                break;
            }node=node->left;
        }
        else
        {
            if(node->right==NULL)
            {
                node->right=p;
                break;
            }node=node->right;
        }
    } 
}
void preorder(struct node*root){
    if(root==NULL) {return;}
    printf("%d->",root->data);
    preorder(root->left);
    preorder(root->right);}
    
void main()
{   root=(struct node*)malloc(sizeof(struct node));
    root->data=20;
    create();
    create();
    create();
    create();
    create();
    preorder(root);
}
