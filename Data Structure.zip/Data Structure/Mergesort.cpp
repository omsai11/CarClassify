#include<iostream>
using namespace std;

    void merge(int arr[],int s,int mid,int e)
    {

        int len1=mid-s+1;
        int len2=e-mid;

        int first[len1];
        int second[len2];

        //copy values
        int index=s;
        for(int i=0;i<len1;i++)
        {
            first[i]=arr[index++];
        }
        index=mid+1;
        for(int i=0;i<len2;i++)
        {
             second[i]=arr[index++];
        }

        //merge 2 sort
        int index1=0;
        int index2=0;
        index=s;

        while(index1<len1 && index2<len2)
        {
            if(first[index1]<second[index2] )
            {
                arr[index++]=first[index1++];
            }
            else{
                arr[index++]=second[index2++];
            }
        }
        while(index1<len1)
        {
             arr[index++]=first[index1++];
        }

        while(index2<len2)
        {
             arr[index++]=second[index2++];
        }
    }
    void mergeSort(int arr[],int s,int e )
    {
        if(s>=e)
        {
            return;
        }
        int mid=(s+e)/2;
        //left part sort karna hai
        mergeSort(arr,s,mid);
        //right part Sort karna hai
        mergeSort(arr,mid+1,e);
        //merge
        merge(arr,s,mid,e);

    }
int main()
{
   int arr[5]={2,5,1,6,9};
   int n=5;
   mergeSort(arr,0,4);
   for(int i=0;i<5;i++)
   {
    cout<<arr[i]<<"-->";
   }
   
}