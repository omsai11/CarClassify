#include<iostream>
using namespace std;
int main()
{   //Entering range of array
int n;
cout<<"Enter the length of array\n";
cin>>n;
int arr[n];
int temp;

//Getting the array elements
cout<<"Enter the elements of array\n";
for(int i=0;i<n;i++)
{
    cin>>arr[i];
}

//Main Code for bubble sort
for(int i=0;i<n;i++)
{
    for(int j=i+1;j<n;j++)
    {
        if(arr[i]>arr[j])
        {
            temp=arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
        }
    }
}

//Display code
for(int i=0;i<n;i++)
{
    cout<<arr[i]<<"-->";
}
        
        return 0;
}