#include<iostream>
using namespace std;
int  main()
{
    int n;
//Inserting the range of array
cout<<"Enter the length of array\n";
cin>>n;
cout<<"Enter the elements\n";
int arr[n];
//getting the elements in the array
for(int i=0;i<n;i++)
{
    cin>>arr[i];
}

//Main code for insertion 
for(int i=1;i<n;i++)
{
    int temp=arr[i];
    int j=i-1;
    while(arr[j]>temp && j>=0)
    {
        arr[j+1]=arr[j];
        j--;
    }
    arr[j+1]=temp;
}

//Display code
for(int i=0;i<n;i++)
{
    cout<<arr[i]<<"-->";
}
return 0;
}