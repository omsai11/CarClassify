#include<stdio.h>
#include<stdlib.h>
struct std{
    int data;
    struct std*right;
    struct std*left;
};
struct std*top;
struct std*root;
void create();
void preorder();
void inorder();
void postorder();
int main()
{
    root=((struct std*)malloc(sizeof(struct std)));
    top=root;
    top->right=NULL;
    top->left=NULL;
    int m;
    printf("enter the data of root\n");
    scanf("%d",&m);
    root->data=m;
   
      create();
      create();
      create();
     
      preorder(root);
      printf("\n");
      inorder(root);
      printf("\n");
      postorder(root);
      printf("\n");
}
void create()
{
    struct std*q;
    q=((struct std*)malloc(sizeof(struct std)));
    int d;
    printf("enter the data\n");
    scanf("%d",&d);
    q->data=d;
    while(top!=q)
    {
        while(top->data>q->data){
            if(top->left==NULL){
                top->left=q;
                top=q;
           
            }
            else{
                top=top->left;
            }
        }
        while(top->data<q->data){
            if(top->right==NULL){
                top->right=q;
                top=q;
           
            }
            else{
                top=top->right;
            }
        }
       
     
    }top=root;
   
   
}
void preorder(struct std*root){
    if(root==NULL) return;
    printf("%d->",root->data);
    preorder(root->left);
    preorder(root->right);
   
}
void inorder(struct std*root){
    if(root==NULL)return;
   
    inorder(root->left);
     printf("%d->",root->data);
    inorder(root->right);
}
    void postorder(struct std*root){
    if(root==NULL)return;
   
    postorder(root->left);
    postorder(root->right);
     printf("%d->",root->data);
    }