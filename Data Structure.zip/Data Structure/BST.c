//Implementing binary search tree 2.0
#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node*left;
    struct node*right;
}*root,*node;
int val;
//creating function 
void create()
{   
    int val;
    printf("Enter the data:\n");
    scanf("%d",&val);

    struct node* p=(struct node*)malloc(sizeof(struct node));
    p->data=val;
    p->left=p->right=NULL;

    node=root;
    while(node!=NULL)
    {
        if(p->data<node->data)
        {
            if(node->left==NULL)
            {
                node->left=p;
                break;
            }node=node->left;
        }
        else
        {
            if(node->right==NULL)
            {
                node->right=p;
                break;
            }node=node->right;
        }
    } 
}
    void preorder(struct node*root){
    if(root==NULL) return;
    printf("%d->",root->data);
    preorder(root->left);
    preorder(root->right);}

    void inorder(struct node*root){
    if(root==NULL) return;
    inorder(root->left);
    printf("%d->",root->data);
    inorder(root->right);}

    void postorder(struct node*root){
    if(root==NULL) return;
    postorder(root->left);
    postorder(root->right);
    printf("%d->",root->data);}

    void traverse(struct node*root)
    {   
         if(root==NULL) return;
         if(root->data==val)
         {  struct node*x=root;
            free(x);
            root->left=NULL;
            root->right=NULL;
            root=NULL;
          
            return;
         }
        traverse(root->left);
        traverse(root->right);
    }

    void delete()
    {
        printf("Enter the node value to delete\n");
        scanf("%d",&val);
        traverse(root);
        
    }

void main()
{   root=(struct node*)malloc(sizeof(struct node));
    printf("Enter the root node data:\n");
    scanf("%d",&root->data);

    int o;
    while(1)
    {
        printf("\nEnter choice \n1.create\t2.delete\t3preorder\t4.inorder\t5.postorder\t6.exit\n");
        scanf("%d",&o);

        switch(o)
        {
            case 1: create();  break;

            case 2: delete(); break;

            case 3: preorder(root); break;

            case 4: inorder(root);  break;

            case 5: postorder(root);  break;

            case 6: exit(1);  break;

            default: printf("Invalid\n"); break;
        }
    }

    
}
