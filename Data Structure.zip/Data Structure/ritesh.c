   //Stack Min Max
#include<stdio.h>
#include<stdlib.h>
int top=-1;
int stack[30];
void push();
void pop_max();
void pop_min();
void display();

int main(){
int choice;
while(1){
printf("\n1.Push\n2.Pop_Max\n3.Pop_min\n4.Display\n5.Exit\n");
printf("Enter a choice:");
scanf("%d",&choice);
switch(choice){

case 1:
push();
break;

case 2:
pop_max();
break;

case 3:
pop_min();
break;

case 4:
display();
break;

case 5:
exit(1);
break;

default:printf("Invalid choice!!!!!");    
}
}
}

void push(){
if(top==29){
printf("Stack is full.");
}
else{
int val;
top++;
printf("Enter a data:");
scanf("%d",&val);
stack[top]=val;
}
}

void pop_max(){
int max=stack[0];
for(int i=1;i<=top;i++){
if(max<stack[i]){
max=stack[i];
stack[i]=stack[top];
i=top;
printf("Deleted element is %d",stack[top]);
top--;
}
}
}

void pop_min(){
int min=stack[top];
for(int i=0;i<=top;i++){
if(min>stack[i]){
min=stack[i];
stack[i]=stack[top];
i=top;
printf("Deleted element is %d",stack[top]);
top--;
}
}
}

void display(){
printf("Elements in the stack are:\n");
for(int j=0;j<=top;j++){
printf("%d\n",stack[j]);
}
}