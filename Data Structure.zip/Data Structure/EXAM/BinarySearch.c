#include <stdio.h>
#include <stdlib.h>

void main()
{
    int min = 0;
    int max = 7;
    int arr[8]={2,4,6,8,10,12,14,16};
    int element;
    printf("Enter the key\n");
    scanf("%d",&element);
    while (min <= max)
    {
        int mid = (max + min) / 2;
        if (arr[mid] == element)
        {
            printf("Key is found at %d\n",mid+1);
            return;
        }
        else if (arr[mid] < element)
        {
            min = mid + 1;
        }
        else if (arr[mid] > element)
        {
            max = mid - 1;
        }
    }
}