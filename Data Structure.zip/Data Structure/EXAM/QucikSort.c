#include<stdio.h>
#include<stdlib.h>

int partition(int arr[],int low,int high)
{
    int pivot=arr[high];
    int i=low-1;
    for(int j=low;j<high;j++)
    {
        if(arr[j]<pivot)
        {
            i++;
            int temp=arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
        }
    }
    i++;
    int temp=arr[i];
    arr[i]=arr[high];
    arr[high]=temp;
    return i;
}

void Quicksort(int arr[],int low,int high)
{
    if(low<high)
    {
        int pidx=partition(arr,low,high);
        Quicksort(arr,low,pidx-1);
        Quicksort(arr,pidx+1,high);
    }
}
void main()
{   int n;
printf("Enter the length of array:");
scanf("%d",&n);

    int arr[n];
    printf("Enter elements in array:\n");
    for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    Quicksort(arr,0,n);
    for(int i=0;i<n;i++)
    {
        printf("%d-->",arr[i]);
    }
    
}