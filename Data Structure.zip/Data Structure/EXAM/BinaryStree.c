#include<stdio.h>
#include<stdlib.h>

struct Tree{
    int data;
    struct Tree* left;
    struct Tree* right;
}*root,*node;
//node can be used as a pointer
int x;
void insert()
{
    int val;
    printf("Enter the data\n");
    scanf("%d",&val);

    //generating memory
    struct Tree* p=(struct Tree*)malloc(sizeof(struct Tree));
    p->data=val;
    p->left=p->right=NULL;

    node=root;
    while(node!=NULL)
    {
        if(p->data<node->data)
        {
            if(node->left==NULL)
            {
                node->left=p;
                break;
            }node=node->left;
        }
        else
        {
            if(node->right==NULL)
            {
                node->right=p;
                break;
            }node=node->right;
        }
    }
}

void Preorder(struct Tree* root)
{
    if(root==NULL)return;
    printf("%d-->",root->data);
    Preorder(root->left);
    Preorder(root->right);
}
void Postorder(struct Tree* root)
{   if(root==NULL)return;
    Postorder(root->left);
    Postorder(root->right);
    printf("%d-->",root->data);
}

void Inorder(struct Tree* root)
{
    if(root==NULL)return;
    Inorder(root->left);
    printf("%d-->",root->data);
    Inorder(root->right);
}
int x;
void Search(struct Tree* root)
{   
    if(x==NULL)
    { 
    printf("Enter the data to search\n");
    scanf("%d",&x);
    }

    if(root==NULL)return;
    if(root->data==x)
    {
        printf("Value is found\n");
    }
    Search(root->left);
    Search(root->right);
}
struct Tree* inorderSucc(struct Tree* root)
{
    struct Tree* curr=root;
    while(curr&&curr->left!=NULL)
    {
        curr=curr->left;
    }
    return curr;
}

struct Tree* Delete(struct Tree* root,int key)
{    if(root==NULL)return;
    if(key<root->data)
    {
        root->left=Delete(root->left,key);
    }
    else if(key>root->data)
    {
        root->right=Delete(root->right,key);
    }
    else
    {
        if(root->left==NULL)
        {
            struct Tree* temp=root->right;
            free(root);
            return temp;
        }
        else if(root->right==NULL)
        {
            struct Tree* temp=root->left;
            free(root);
            return temp;
        }
        else
        {
            struct Tree* temp=inorderSucc(root->right);
            root->data=temp->data;
            root->right=Delete(root->right,temp->data);
        }
        return root;
    }
}

void main()
{
    root=(struct Tree*)malloc(sizeof(struct Tree));
    root->data=10;
    insert();
    insert();
    insert();
    insert();
    Preorder(root);
    Postorder(root);
    Inorder(root);
    Delete(root,5);
}
