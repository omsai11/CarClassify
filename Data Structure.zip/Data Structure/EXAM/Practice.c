// //Quick Sort
// #include<stdio.h>
// #include<stdlib.h>

// int partition(int arr[],int low,int high)
// {
//     int pivot=arr[high];
//     int i=low-1;

//     for(int j=low;j<high;j++)
//     {
//         if(arr[j]<arr[high])
//         {
//             i++;
//             int temp=arr[i];
//             arr[i]=arr[j];
//             arr[j]=temp;
//         }
//     }
//     i++;
//     int temp=arr[i];
//     arr[i]=arr[high];
//     arr[high]=arr[i];
//     return i;
// }

// void Quicksort(int arr[],int low,int high)
// {
//     if(low<high)
//     {
//         int pidx=partition(arr,low,high);
//         Quicksort(arr,low,pidx-1);
//         Quicksort(arr,pidx+1,high);
//     }
// }

// void main()
// {
//     int arr[5]={5,3,4,6,7};
//     Quicksort(arr,0,4);
//     for(int i=0;i<5;i++)
//     {
//         printf("%d-->",arr[i]);
//     }
// }



// //Bubble Sort

// #include<stdlib.h>
// #include<stdio.h>

// void main()
// {
//     int arr[]={3,5,6,7,8,9,3,4,5,2};

//     for(int i=0;i<10;i++)
//     {
//         for(int j=i+1;j<10;j++)
//         {
//             if(arr[j]<arr[i])
//             {
//                 int temp=arr[j];
//                 arr[j]=arr[i];
//                 arr[i]=temp;
//             }
//         }
//     }
//     for(int i=0;i<10;i++)
//     {
//         printf("%d-->",arr[i]);
//     }
// }

//Merge Sort

// #include<stdio.h>
// #include<stdlib.h>

// //merge function
// void merge(int arr[],int s,int mid,int e)
// {
//     int len1=mid-s+1;
//     int len2=e-mid;
//     int first[len1];
//     int second[len2];

//     //copy valiues
//     int index=s;
//     for(int i=0;i<len1;i++)
//     {
//         first[i]=arr[index++];
//     }
//     index=mid+1;
//     for(int i=0;i<len2;i++)
//     {
//         second[i]=arr[index++];
//     }

//     //merge 2sort
//     int index1=0;
//     int index2=0;
//     index=s;

//     while(index1<len1&&index2<len2)
//     {
//         if(first[index1]<second[index2])
//         {
//             arr[index++]=first[index1++];
//         }
//         else
//         {
//             arr[index++]=second[index2++];
//         }
//     }

//     while(index1<len1)
//     {
//         arr[index++]=first[index1++];
//     }
//     while(index2<len2)
//     {
//         arr[index++]=second[index2++];
//     }
// }

// void mergesort(int arr[],int s,int e)
// {
//     if(s>=e)
//     {
//         return;
//     }

//     int mid=(s+e)/2;
//     //left part sorting
//     mergesort(arr,s,mid);

//     //right part sorting
//     mergesort(arr,mid+1,e);
//     merge(arr,s,mid,e);
// }
// int main()
// {
//    int arr[5]={2,5,1,6,9};
//    int n=5;
//    mergesort(arr,0,4);
//    for(int i=0;i<5;i++)
//    {
//      printf("%d-->",arr[i]);
//    }
   
// }

// //Binary Search
// #include<stdio.h>
// #include<stdlib.h>

// void main()
// {
//     int min=0;
//     int max=9;
//     int arr[10]={1,2,3,4,5,6,7,8,9,10};

//     int val;
//     int j=0;
//     printf("Enter the key to find\n");
//     scanf("%d",&val);

//     while(min<=max)
//     {
//         int mid=(min+max)/2;
//         if(arr[mid]==val)
//         {
//             printf("Key is found at poistion %d\n",mid+1);
//             j=1;
//             return;
//         }
//         else if(arr[mid]<val)
//         {
//             min=mid+1;
//         }
//         else
//         {   
//             max=mid-1;
//         }
//     }
//     if(j!=1)printf("Key is not found at any position\n");
// }

//Binary Search TRee
#include<stdio.h>
#include<stdlib.h>

struct tree{
    int data;
    struct tree* left;
    struct tree* right;
}*root,*node;

void insert(){
    int val;
    printf("Enter the data\n");
    scanf("%d",&val);

    struct tree* p=(struct tree*)malloc(sizeof(struct tree));
    p->data=val;
    p->left=p->right=NULL;

    node=root;
    while(node!=NULL)
    {
        if(p->data<node->data)
        {
            if(node->left==NULL)
            {
                node->left=p;
                break;
            }node=node->left;
        }
        else
        {
            if(node->right==NULL)
            {
                node->right=p;
                break;
            }node=node->right;
        }
    }
}

void Preorder(struct tree* root)
{
    if(root==NULL)return;
    printf("%d-->",root->data);
    Preorder(root->left);
    Preorder(root->right);
}

void Inorder(struct tree* root)
{
    if(root==NULL)return;
    Inorder(root->left);
    printf("%d-->",root->data);
    Inorder(root->right);
}

void Postorder(struct tree* root)
{
    if(root==NULL)return;
    Postorder(root->left);
    Postorder(root->right);
    printf("%d-->",root->data);
}
struct tree* inorderSucc(struct tree* root)
{
    struct tree* curr=root;
    while(curr&&curr->left!=NULL)
    {
        curr=curr->left;
    }
    return curr;
}
struct tree* Delete(struct tree* root,int key)
{   if(root==NULL)
    return root;

    if(key<root->data)
    {
        root->left=Delete(root->left,key);
    }
    else if(key>root->data)
    {
        root->right=Delete(root->right,key);
    }
    else{
        if(root->left==NULL)
        {
            struct tree* temp=root->right;
            free(root);
            return temp;
        }
        else if(root->right==NULL)
        {
            struct tree* temp=root->left;
            free(root);
            return temp;
        }
        else
        {
            struct tree* temp=inorderSucc(root->right);
            root->data=temp->data;
            root->right=Delete(root->right,temp->data);
        }
        return 1;
    }
}

void main()
{
    root=(struct tree*)malloc(sizeof(struct tree));
    root->data=20;
    insert();
    insert();
    insert();
    insert();
    Preorder(root);
    printf("\n");
    Postorder(root);
    printf("\n");
    Inorder(root);
    printf("\n");
    Delete(root,5);
    Inorder(root);
}