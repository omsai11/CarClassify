#include<stdio.h>
#include<stdlib.h>

void main()
{
    int arr[]={4,6,2,1,7,8,4,2,9,1};
    int j=0;
    printf("Enter the key to search\n");
    int val;
    scanf("%d",&val);
    for(int i=0;i<10;i++)
    {
        if(val==arr[i])
        {
            printf("Key is found at %d position\n",i+1);
            j=1;
        }
    }
    if(j!=1)printf("key is not found here\n");
}